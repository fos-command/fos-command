FOS COMMAND — PARTAGE 9 ACCÈS (PRÉPARATION À DÉPLOYER)

Cette archive n'est PAS encore déployée. Elle conserve l'interface, le bilingue et les icônes de l'application actuelle et ajoute l'API D1, la connexion et l'administration des 9 places.

IMPORTANT AVANT DÉPLOIEMENT
1. L’ID réel de fos-command-db est déjà renseigné dans wrangler.jsonc. Le binding D1 s’appelle DB.
2. Dans Cloudflare > D1 > fos-command-db > Console, exécuter tout le contenu de schema.sql. Cela crée les tables et l’espace de données partagées.
3. Déployer ce projet comme nouveau Worker (ou nouvelle version de service) avec Wrangler : `npx wrangler deploy`. Le dossier contient src/index.js et public/ ; le fichier wrangler.jsonc configure les assets et la liaison D1. Ne remplace pas le Worker actuellement en ligne tant que les tests ne sont pas validés.
4. Dans les paramètres du nouveau Worker, ajouter un secret nommé ADMIN_SETUP_KEY avec une valeur longue et aléatoire.
5. Créer le premier administrateur une seule fois via POST /api/admin/bootstrap avec le JSON {"key":"VALEUR_DU_SECRET","username":"ton_identifiant","displayName":"Administrateur FOS","password":"mot_de_passe_long"}. Ne jamais mettre la clé ou le mot de passe dans le code. Le formulaire de première configuration de l’application envoie cette requête.
6. Tester la connexion et le panneau « Gestion des accès ». L’administrateur attribue/remplace/libère les 9 places. Les comptes R4/R5 ont les mêmes droits de modification des données collectives.
7. Quand tout est vérifié, seulement alors rattacher le domaine de l’application à ce Worker. Garder l’ancienne version disponible tant que les tests ne sont pas terminés.

MIGRATION
Au premier démarrage, si la base est vide, l'administrateur connecté importe les données locales présentes sur SON navigateur. Vérifier que c'est bien le navigateur qui contient les données actuelles avant le premier accès.

LIMITES À CONNAÎTRE
- Sauvegarde partagée via D1; la synchro est déclenchée à chaque modification. La version D1 empêche les écrasements silencieux : une modification concurrente déclenche une alerte et demande un rechargement avant de ressaisir. Les autres modifications apparaissent par actualisation automatique (environ 5 secondes).
- Chaque place peut être libérée; son compte est désactivé et ses sessions invalidées. Les données collectives restent intactes.
- Les mots de passe sont hachés PBKDF2 et les sessions utilisent un cookie HttpOnly/Secure.
- Garder l'ancienne version disponible tant que les tests ne sont pas terminés.
